package com.Mi22a.meilisauts

import android.icu.text.CaseMap.Title
import java.security.cert.CertPath

data class Course(
    val title:String,
    val path:String,
    val image:String,

)
